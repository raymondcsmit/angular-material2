export interface RevenueChartData {
  groupA: number;
  groupB: number;
  groupC: number;
  groupD: number;
}
