export const googleMapKey: string = 'AIzaSyB7OXmzfQYua_1LEhRdqsoYzyJOPh9hGLg';
