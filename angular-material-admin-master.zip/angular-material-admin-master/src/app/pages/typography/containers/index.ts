export * from './typography-page/typography-page.component';
