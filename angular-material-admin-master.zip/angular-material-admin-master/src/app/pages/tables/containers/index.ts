export * from './tables-page/tables-page.component';
