export interface Employee {
  name: string;
  company: string;
  city: string;
  state: string;
}
